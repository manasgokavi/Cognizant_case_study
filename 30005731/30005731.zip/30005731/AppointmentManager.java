import java.sql.*;
import java.util.Scanner;

public class AppointmentManager {
    public static void manageAppointments(Scanner scanner) {
        System.out.println("1. Schedule Appointment\n2. View Appointment\n3. Update Appointment\n4. Cancel Appointment");
        switch (scanner.nextInt()) {
            case 1: 
                scheduleAppointment(scanner); break;
            case 2: 
                viewAppointment(scanner); break;
            case 3: 
                updateAppointment(scanner); break;
            case 4: 
                cancelAppointment(scanner); break;
        }
    }

    private static void scheduleAppointment(Scanner scanner) {
        System.out.print("Customer ID, Service ID, Date (YYYY-MM-DD), Time (HH:MM:SS): ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Appointment (customer_id, service_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)")) {
            stmt.setInt(1, scanner.nextInt());
            stmt.setInt(2, scanner.nextInt());
            stmt.setDate(3, Date.valueOf(scanner.next()));
            stmt.setTime(4, Time.valueOf(scanner.next()));
            stmt.executeUpdate();
            System.out.println("Appointment scheduled.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAppointment(Scanner scanner) {
        System.out.print("Appointment ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Appointment WHERE appointment_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("appointment_id") + ", Date: " + rs.getDate("appointment_date") + ", Time: " + rs.getTime("appointment_time"));
            } else {
                System.out.println("No such appointment.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAppointment(Scanner scanner) {
        System.out.print("ID, New Customer ID, New Service ID, New Date (YYYY-MM-DD), New Time (HH:MM:SS): ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE Appointment SET customer_id = ?, service_id = ?, appointment_date = ?, appointment_time = ? WHERE appointment_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            stmt.setInt(2, scanner.nextInt());
            stmt.setDate(3, Date.valueOf(scanner.next()));
            stmt.setTime(4, Time.valueOf(scanner.next()));
            stmt.setInt(5, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Appointment updated.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void cancelAppointment(Scanner scanner) {
        System.out.print("Appointment ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Appointment WHERE appointment_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Appointment canceled.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
