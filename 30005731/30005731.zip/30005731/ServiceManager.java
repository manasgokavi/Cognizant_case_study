import java.sql.*;
import java.util.Scanner;

public class ServiceManager {
    public static void manageServices(Scanner scanner) {
        System.out.println("1. Add Service\n2. View Service\n3. Update Service\n4. Delete Service");
        switch (scanner.nextInt()) {
            case 1: 
                addService(scanner); break;
            case 2: 
                viewService(scanner); break;
            case 3: 
                updateService(scanner); break;
            case 4: 
                deleteService(scanner); break;
        }
    }

    private static void addService(Scanner scanner) {
        System.out.print("Name, Description, Duration, Price: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Service (service_name, description, duration, price) VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, scanner.next());
            stmt.setString(2, scanner.next());
            stmt.setInt(3, scanner.nextInt());
            stmt.setDouble(4, scanner.nextDouble());
            stmt.executeUpdate();
            System.out.println("Service added.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewService(Scanner scanner) {
        System.out.print("Service ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Service WHERE service_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("service_id") + ", Name: " + rs.getString("service_name"));
            } else {
                System.out.println("No such service.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateService(Scanner scanner) {
        System.out.print("ID, New Name, New Description, New Duration, New Price: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE Service SET service_name = ?, description = ?, duration = ?, price = ? WHERE service_id = ?")) {
            stmt.setString(1, scanner.next());
            stmt.setString(2, scanner.next());
            stmt.setInt(3, scanner.nextInt());
            stmt.setDouble(4, scanner.nextDouble());
            stmt.setInt(5, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Service updated.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteService(Scanner scanner) {
        System.out.print("Service ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Service WHERE service_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Service deleted.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
