import java.sql.*;
import java.util.Scanner;

public class CustomerManager {
    public static void manageCustomers(Scanner scanner) {
        System.out.println("1. Register Customer\n2. View Customer\n3. Update Customer\n4. Delete Customer");
        switch (scanner.nextInt()) {
            case 1: 
                registerCustomer(scanner); break;
            case 2: 
                viewCustomer(scanner); break;
            case 3: 
                updateCustomer(scanner); break;
            case 4: 
                deleteCustomer(scanner); break;
        }
    }

    private static void registerCustomer(Scanner scanner) {
        System.out.print("Name, Email, Phone: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO Customer (customer_name, email, phone_number) VALUES (?, ?, ?)")) {
            stmt.setString(1, scanner.next());
            stmt.setString(2, scanner.next());
            stmt.setString(3, scanner.next());
            stmt.executeUpdate();
            System.out.println("Customer registered.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewCustomer(Scanner scanner) {
        System.out.print("Customer ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Customer WHERE customer_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("customer_id") + ", Name: " + rs.getString("customer_name"));
            } else {
                System.out.println("No such customer.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCustomer(Scanner scanner) {
        System.out.print("ID, New Name, New Email, New Phone: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE Customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?")) {
            stmt.setString(1, scanner.next());
            stmt.setString(2, scanner.next());
            stmt.setString(3, scanner.next());
            stmt.setInt(4, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Customer updated.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteCustomer(Scanner scanner) {
        System.out.print("Customer ID: ");
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Customer WHERE customer_id = ?")) {
            stmt.setInt(1, scanner.nextInt());
            stmt.executeUpdate();
            System.out.println("Customer deleted.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
