import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Manage Customers\n2. Manage Services\n3. Manage Appointments\n4. Exit");
            switch (scanner.nextInt()) {
                case 1: CustomerManager.manageCustomers(scanner); break;
                case 2: ServiceManager.manageServices(scanner); break;
                case 3: AppointmentManager.manageAppointments(scanner); break;
                case 4: System.out.println("Exiting..."); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }
}
